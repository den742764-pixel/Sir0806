'use strict';
const assert=require('node:assert/strict');const crypto=require('node:crypto');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const net=require('node:net');const {spawn}=require('node:child_process');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p))})})}
async function main(){
 const port=await freePort(),data=fs.mkdtempSync(path.join(os.tmpdir(),'sirius-premium-')),secret='premium-test-secret-that-is-longer-than-32-chars';
 const child=spawn(process.execPath,[path.join(__dirname,'server.js')],{cwd:__dirname,env:{...process.env,PORT:String(port),DATA_DIR:data,DEV_CODE:secret,NODE_ENV:'test',REQUIRE_HTTPS:'0',REDIS_URL:''},stdio:['ignore','pipe','pipe']});let logs='';child.stdout.on('data',d=>logs+=d.toString());child.stderr.on('data',d=>logs+=d.toString());const base=`http://127.0.0.1:${port}/api/`;
 async function post(route,body){const r=await fetch(base+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return{status:r.status,body:await r.json()}}
 async function register(un){const token=crypto.randomBytes(32).toString('hex'),ecdh=crypto.createECDH('prime256v1');ecdh.generateKeys();const pub=ecdh.getPublicKey(),pk=JSON.stringify({kty:'EC',crv:'P-256',x:pub.subarray(1,33).toString('base64url'),y:pub.subarray(33,65).toString('base64url'),ext:true,key_ops:[]});const r=await post('auth/register',{token,name:un,un,pk,seen:Date.now(),salt:'YWJjZGVmZ2hpamtsbW5vcA==',proof:'a'.repeat(64),vault:'YWJjZGVmZ2hpamtsb25hc2R1dnd4eXo='});assert.equal(r.status,200,'register '+un+': '+JSON.stringify(r.body));return{u:r.body.uid,t:token}}
 try{
  let ready=false;for(let i=0;i<80;i++){if(child.exitCode!==null)throw Error('server exited: '+logs);try{if((await fetch(base+'ping',{signal:AbortSignal.timeout(500)})).ok){ready=true;break}}catch{}await wait(100)}assert(ready,'server did not start: '+logs);
  const owner=await register('premium_owner'),buyer=await register('premium_buyer');
  let r=await post('dev/redeem',{u:owner.u,t:owner.t,code:secret,amt:0});assert.equal(r.status,200,'owner activation');
  r=await post('admin/grant',{u:owner.u,t:owner.t,un:'premium_buyer',amt:2000});assert.equal(r.status,200,'grant stars');
  r=await post('support/create',{u:buyer.u,t:buyer.t,message:'Не могу изменить фото профиля'});assert.equal(r.status,200,'support ticket create');
  r=await post('admin/list',{u:owner.u,t:owner.t});assert.equal(r.status,200);assert.equal(r.body.support.length,1,'support ticket visible to owner');
  const ticket=r.body.support[0];r=await post('admin/support-reply',{u:owner.u,t:owner.t,id:ticket.id,reply:'Откройте профиль и нажмите на значок камеры.'});assert.equal(r.status,200,'support reply');
  r=await post('admin/list',{u:owner.u,t:owner.t});assert.equal(r.body.support.length,0,'answered ticket closed');
  r=await post('premium/buy',{u:buyer.u,t:buyer.t,days:90});assert.equal(r.status,200,'90-day premium buy: '+JSON.stringify(r.body));assert.equal(r.body.days,90);assert.equal(r.body.price,1350);
  r=await post('premium/state',{u:buyer.u,t:buyer.t});assert.equal(r.body.active,true);assert(r.body.until>Date.now()+89*86400000);assert.equal(r.body.bal,700);assert.equal(r.body.plans.length,4,'all subscription plans exposed');
  r=await post('premium/buy',{u:buyer.u,t:buyer.t,days:45});assert.notEqual(r.status,200,'unsupported duration rejected');
  r=await post('premium/gift',{u:buyer.u,t:buyer.t,un:'premium_owner'});assert.equal(r.status,200,'premium gift: '+JSON.stringify(r.body));
  r=await post('premium/state',{u:owner.u,t:owner.t});assert.equal(r.body.active,true,'recipient premium active');
  r=await post('premium/state',{u:buyer.u,t:buyer.t});assert.equal(r.body.bal,50,'gift price debited exactly once');
  r=await post('premium/gift',{u:buyer.u,t:buyer.t,un:'missing_user'});assert.notEqual(r.status,200,'unknown recipient rejected');
  console.log('PASS: support bot tickets, owner replies, Premium purchase, multi-month activation, invalid-duration rejection, gift purchase, balance debits and invalid recipient rejection');
 }finally{child.kill('SIGTERM');await Promise.race([new Promise(resolve=>child.once('exit',resolve)),wait(2000)]);if(child.exitCode===null)child.kill('SIGKILL');fs.rmSync(data,{recursive:true,force:true})}
}
main().catch(e=>{console.error('FAIL:',e.stack||e);process.exitCode=1});
