'use strict';
// Live-process smoke test: start, health endpoint, HTML/CSP, frontend/API contract and clean HTTP errors.
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const vm=require('node:vm');
const net=require('node:net');
const {spawn}=require('node:child_process');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p))})})}
async function main(){
 const port=await freePort(),data=fs.mkdtempSync(path.join(os.tmpdir(),'sirius-runtime-'));
 const secret='runtime-smoke-secret-0123456789-ABCDEFGHIJKLMNOPQRSTUVWXYZ';
 const child=spawn(process.execPath,[path.join(__dirname,'server.js')],{cwd:__dirname,env:{...process.env,PORT:String(port),DATA_DIR:data,DEV_CODE:secret,NODE_ENV:'test',REQUIRE_HTTPS:'0',REDIS_URL:''},stdio:['ignore','pipe','pipe']});
 let logs='';child.stdout.on('data',d=>logs+=d.toString());child.stderr.on('data',d=>logs+=d.toString());
 const base=`http://127.0.0.1:${port}`;
 try{
  let ready=false;
  for(let i=0;i<100;i++){
   if(child.exitCode!==null)throw new Error('server exited during startup: '+logs);
   try{const r=await fetch(base+'/api/ping',{signal:AbortSignal.timeout(500)});if(r.status===200){ready=true;break}}catch{}
   await wait(100);
  }
  assert(ready,'server did not start or /api/ping failed: '+logs);
  const ping=await fetch(base+'/api/ping');assert.deepEqual(await ping.json(),{ok:1});
  const page=await fetch(base+'/');assert.equal(page.status,200,'root page did not load');assert.match(page.headers.get('content-type')||'',/text\/html/i);
  for(const [h,v] of [['x-content-type-options','nosniff'],['x-frame-options','DENY'],['referrer-policy','no-referrer']])assert.equal(page.headers.get(h),v,`missing security header ${h}`);
  const html=await page.text();assert(html.length>50000,'unexpectedly empty or truncated UI');assert.match(html,/<html[\s>]/i,'HTML document missing');
  const csp=page.headers.get('content-security-policy')||'';assert(csp.includes("script-src 'self'"),'script CSP missing');
  const scripts=[...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi)].map(m=>m[1]);
  assert(scripts.length>0,'inline application script missing');
  const expected=scripts.map(s=>"'sha256-"+crypto.createHash('sha256').update(s).digest('base64')+"'");
  for(const h of expected)assert(csp.includes(h),'CSP hash does not match an inline script');
  scripts.forEach((s,i)=>new vm.Script(s,{filename:`index-inline-${i}.js`}));
  const server=fs.readFileSync(path.join(__dirname,'server.js'),'utf8');
  const declared=new Set([...server.matchAll(/^\s*'([a-z]+\/[a-z]+)'\s*:\s*\{/gm)].map(m=>m[1]));
  const called=new Set([...html.matchAll(/api\(['"]([a-z]+\/[a-z]+)['"]/g)].map(m=>m[1]));
  for(const ep of called)assert(declared.has(ep),`frontend calls missing server endpoint: ${ep}`);
  const unauth=await fetch(base+'/api/shop/state',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({u:'12345678',t:'not-a-valid-token'})});assert.equal(unauth.status,401,'protected API did not reject unauthenticated access');
  const wrongType=await fetch(base+'/api/auth/register',{method:'POST',headers:{'content-type':'text/plain'},body:'{}'});assert.equal(wrongType.status,415,'API accepted a non-JSON content type');
  const missing=await fetch(base+'/not-a-real-route');assert.equal(missing.status,404,'unknown route did not return 404');
  console.log(`PASS: live startup, health, HTML/CSP hashes, inline JS parse, ${called.size} frontend API routes, auth gate and HTTP error paths`);
 }finally{
  child.kill('SIGTERM');await Promise.race([new Promise(resolve=>child.once('exit',resolve)),wait(2000)]);if(child.exitCode===null)child.kill('SIGKILL');fs.rmSync(data,{recursive:true,force:true});
 }
}
main().catch(e=>{console.error('FAIL:',e.stack||e);process.exitCode=1});
